
import React, { useState } from 'react';

interface QuickActionsFABProps {
  onAction: (action: 'scan' | 'health' | 'quick_order') => void;
}

export const QuickActionsFAB: React.FC<QuickActionsFABProps> = ({ onAction }) => {
  const [isOpen, setIsOpen] = useState(false);

  const ACTIONS = [
    { id: 'scan', label: 'Scan Photo', icon: 'photo_camera', color: 'bg-sunset' },
    { id: 'health', label: 'Health Scan', icon: 'health_and_safety', color: 'bg-mint' },
    { id: 'quick_order', label: 'Quick Order', icon: 'bolt', color: 'bg-lemon' },
  ] as const;

  return (
    <div className="fixed bottom-28 right-6 z-[1000] flex flex-col items-end gap-3">
      {isOpen && (
        <div className="flex flex-col gap-3 mb-2 animate-in slide-in-from-bottom-4 duration-300">
          {ACTIONS.map((action) => (
            <button
              key={action.id}
              onClick={() => {
                onAction(action.id);
                setIsOpen(false);
              }}
              className="flex items-center gap-3 group"
            >
              <span className="bg-white dark:bg-midnight px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl border border-slate-100 dark:border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
                {action.label}
              </span>
              <div className={`${action.color} w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-xl hover:scale-110 active:scale-95 transition-all border-2 border-white/20`}>
                <span className="google-symbols">{action.icon}</span>
              </div>
            </button>
          ))}
        </div>
      )}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-16 h-16 rounded-[2rem] flex items-center justify-center shadow-2xl transition-all border-4 border-white dark:border-midnight z-50 ${
          isOpen ? 'bg-midnight text-white rotate-45' : 'bg-sunset text-white'
        }`}
      >
        <span className="google-symbols text-3xl font-black">{isOpen ? 'close' : 'add'}</span>
      </button>
    </div>
  );
};
