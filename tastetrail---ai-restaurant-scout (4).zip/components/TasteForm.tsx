
import React, { useState, useRef, useEffect } from 'react';
import { TasteProfile, FlavorIntensity } from '../types';

interface TasteFormProps {
  onSearch: (profile: TasteProfile, photoBase64?: string) => void;
  isLoading: boolean;
}

const RECENT_SEARCHES_KEY = 'tastetrail_recent_v2';

const DISCOVERY_RANGES = [
  { id: '5km', label: 'Nearby', desc: 'Walking distance', icon: 'directions_walk' },
  { id: '25km', label: 'Citywide', desc: 'Commutable range', icon: 'directions_car' },
  { id: '100km', label: 'Regional', desc: 'Wider expedition', icon: 'explore' },
  { id: 'Global', label: 'Global', desc: 'World-class gems', icon: 'public' }
];

const QUICK_CATEGORIES = [
  { id: 'breakfast', label: 'Breakfast', icon: 'bakery_dining', color: 'bg-amber-100 text-amber-700' },
  { id: 'street_food', label: 'Street Food', icon: 'fastfood', color: 'bg-rose-100 text-rose-700' },
  { id: 'healthy', label: 'Healthy', icon: 'eco', color: 'bg-emerald-100 text-emerald-700' },
  { id: 'fine_dining', label: 'Fine Dining', icon: 'restaurant', color: 'bg-indigo-100 text-indigo-700' },
  { id: 'desserts', label: 'Desserts', icon: 'cake', color: 'bg-pink-100 text-pink-700' },
  { id: 'date_night', label: 'Date Night', icon: 'favorite', color: 'bg-red-100 text-red-700' },
];

const QUICK_FILTERS = [
  { id: 'trending', label: 'Trending', icon: 'local_fire_department' },
  { id: 'healthy', label: 'Healthy', icon: 'eco' },
  { id: 'budget', label: 'Budget-friendly', icon: 'payments' },
  { id: 'fast', label: 'Fast Delivery', icon: 'bolt' },
];

const SUGGESTION_POOL = [
  "Spicy Ramen", "Sushi Platter", "Butter Chicken", "Keto Salad", "Avocado Toast",
  "Truffle Pasta", "Margarita Pizza", "Dim Sums", "Paneer Tikka", "Hyderabadi Biryani",
  "Vegan Burger", "Matcha Latte", "Street Tacos", "Healthy Smoothie Bowl", "Cheesecake"
];

const FLAVOR_OPTIONS = [
  { name: 'Spicy', emoji: '🌶️', color: 'bg-rose-500' },
  { name: 'Sweet', emoji: '🍬', color: 'bg-amber-400' },
  { name: 'Umami', emoji: '🍄', color: 'bg-slate-700' },
  { name: 'Tangy', emoji: '🍋', color: 'bg-yellow-400' },
  { name: 'Salty', emoji: '🧂', color: 'bg-blue-400' },
  { name: 'Bitter', emoji: '☕', color: 'bg-stone-600' },
  { name: 'Smoky', emoji: '🪵', color: 'bg-orange-800' },
  { name: 'Creamy', emoji: '🥛', color: 'bg-blue-200' },
];

export const TasteForm: React.FC<TasteFormProps> = ({ onSearch, isLoading }) => {
  const [profile, setProfile] = useState<TasteProfile>({
    dietaryPreferences: [], favoriteFlavors: [], preferredTextures: [], preferredCuisines: [], features: [],
    atmosphere: "Lively", diningTheme: "Casual", budget: "₹₹", customNotes: "",
    occasion: 'Solo', maxDistance: "25km", ageGroup: 'Adult', comfortPreference: 'Casual',
    healthGoal: 'Balanced', spiceTolerance: 'Medium', isHealthyScout: false, onlineOrderingOnly: false,
    deliveryPriority: 'Quality'
  });

  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [searchInput, setSearchInput] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isFlavorDropdownOpen, setIsFlavorDropdownOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const stored = localStorage.getItem(RECENT_SEARCHES_KEY);
    if (stored) setRecentSearches(JSON.parse(stored));
  }, []);

  const saveToHistory = (query: string) => {
    if (!query.trim()) return;
    const updated = [query, ...recentSearches.filter(s => s !== query)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
  };

  const handleInputChange = (val: string) => {
    setSearchInput(val);
    if (val.trim().length > 1) {
      const filtered = SUGGESTION_POOL.filter(s => s.toLowerCase().includes(val.toLowerCase())).slice(0, 5);
      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const selectSuggestion = (s: string) => {
    setSearchInput(s);
    setShowSuggestions(false);
    onSearch({ ...profile, customNotes: s }, previewImage || undefined);
    saveToHistory(s);
  };

  const toggleSelection = (list: string[], item: string, key: keyof TasteProfile) => {
    const newList = list.includes(item) ? list.filter(i => i !== item) : [...list, item];
    setProfile({...profile, [key]: newList});
    if ('vibrate' in navigator) navigator.vibrate(10);
  };

  const handleFlavorToggle = (flavorName: string) => {
    const existing = profile.favoriteFlavors.find(f => f.name === flavorName);
    if (existing) {
      setProfile({
        ...profile,
        favoriteFlavors: profile.favoriteFlavors.filter(f => f.name !== flavorName)
      });
    } else {
      setProfile({
        ...profile,
        favoriteFlavors: [...profile.favoriteFlavors, { name: flavorName, level: 3 }]
      });
    }
    if ('vibrate' in navigator) navigator.vibrate(10);
  };

  const handleIntensityChange = (flavorName: string, level: number) => {
    setProfile({
      ...profile,
      favoriteFlavors: profile.favoriteFlavors.map(f => 
        f.name === flavorName ? { ...f, level } : f
      )
    });
    if ('vibrate' in navigator) navigator.vibrate(5);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPreviewImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({ ...profile, customNotes: searchInput }, previewImage || undefined);
    saveToHistory(searchInput);
    setShowSuggestions(false);
  };

  return (
    <div className="space-y-12 pb-32 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-1000">
      <header className="relative py-8 px-8 text-center space-y-2">
        <h2 className="text-5xl font-serif font-black tracking-tight text-slate-900 dark:text-white leading-[1.1]">
          Fast <span className="text-sunset">Discovery.</span>
        </h2>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">One Tap Connection</p>
      </header>

      {/* Main Search Bar */}
      <section className="px-6 space-y-4 relative z-[100]">
        <form onSubmit={handleSubmit} className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-sunset to-lemon rounded-[2rem] blur opacity-10 group-focus-within:opacity-30 transition duration-500"></div>
          <div className="relative bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 rounded-[2rem] p-2 flex items-center shadow-xl">
             <div className="w-12 h-12 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 ml-1">
                <span className="google-symbols text-2xl">search</span>
             </div>
             <input 
               type="text"
               value={searchInput}
               onChange={(e) => handleInputChange(e.target.value)}
               onFocus={() => searchInput.length > 1 && setShowSuggestions(true)}
               placeholder="Crave something? (e.g. Spicy Ramen)"
               className="flex-1 bg-transparent border-none outline-none px-4 py-3 font-bold text-sm text-slate-800 dark:text-white"
             />
             <button 
               type="submit"
               disabled={isLoading}
               className="bg-sunset text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-orange-600 transition-all active:scale-95 shadow-lg shadow-sunset/20"
             >
               Scout
             </button>
          </div>
          
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-4 right-4 mt-2 bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden animate-in slide-in-from-top-2">
              {suggestions.map((s, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => selectSuggestion(s)}
                  className="w-full px-6 py-4 text-left font-bold text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-3 transition-colors border-b last:border-0 border-slate-50 dark:border-slate-800"
                >
                  <span className="google-symbols text-slate-300">history</span>
                  {s}
                </button>
              ))}
            </div>
          )}
        </form>

        <div className="flex gap-2 overflow-x-auto no-scrollbar py-2">
          {QUICK_FILTERS.map(filter => (
            <button
              key={filter.id}
              onClick={() => toggleSelection(profile.features, filter.label, 'features')}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest border-2 transition-all ${
                profile.features.includes(filter.label)
                ? 'bg-sunset border-sunset text-white shadow-md'
                : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-500'
              }`}
            >
              <span className="google-symbols text-sm">{filter.icon}</span>
              {filter.label}
            </button>
          ))}
        </div>
      </section>

      {/* Flavor Selection Refactor */}
      <section className="px-6 space-y-6">
        <label className="text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.3em] flex items-center gap-3">
          <span className="google-symbols text-sm text-sunset">psychology</span> Sensory DNA
        </label>
        
        <div className="relative">
          <button 
            onClick={() => setIsFlavorDropdownOpen(!isFlavorDropdownOpen)}
            className="w-full bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 p-4 rounded-3xl flex items-center justify-between shadow-sm group hover:border-sunset/30 transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400">
                <span className="google-symbols">palette</span>
              </div>
              <span className="text-sm font-bold text-slate-500">Add flavor nodes...</span>
            </div>
            <span className={`google-symbols text-slate-400 transition-transform ${isFlavorDropdownOpen ? 'rotate-180' : ''}`}>expand_more</span>
          </button>

          {isFlavorDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-3 bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-slate-800 p-3 grid grid-cols-2 gap-2 z-[200] animate-in slide-in-from-top-4 duration-300">
              {FLAVOR_OPTIONS.map(opt => {
                const isSelected = profile.favoriteFlavors.some(f => f.name === opt.name);
                return (
                  <button
                    key={opt.name}
                    onClick={() => handleFlavorToggle(opt.name)}
                    className={`p-4 rounded-2xl flex items-center gap-3 transition-all ${
                      isSelected ? 'bg-sunset text-white' : 'bg-slate-50 dark:bg-slate-800 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-xl">{opt.emoji}</span>
                    <span className="text-[10px] font-black uppercase tracking-widest">{opt.name}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Selected Flavors with Intensity Controls */}
        <div className="space-y-3">
          {profile.favoriteFlavors.map(flavor => {
            const opt = FLAVOR_OPTIONS.find(o => o.name === flavor.name)!;
            return (
              <div key={flavor.name} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-[2.5rem] flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-sm animate-in slide-in-from-left-4">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 ${opt.color} rounded-2xl flex items-center justify-center text-white text-2xl shadow-lg`}>
                    {opt.emoji}
                  </div>
                  <div>
                    <h4 className="text-sm font-black uppercase tracking-widest text-slate-800 dark:text-slate-200">{flavor.name}</h4>
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter mt-1">Level {flavor.level} Intensity</p>
                  </div>
                </div>

                <div className="flex-1 max-w-xs flex items-center gap-4">
                  <div className="flex-1 flex gap-2">
                    {[1, 2, 3, 4, 5].map(step => (
                      <button
                        key={step}
                        onClick={() => handleIntensityChange(flavor.name, step)}
                        className={`h-2 flex-1 rounded-full transition-all ${
                          step <= flavor.level ? opt.color : 'bg-slate-100 dark:bg-slate-800'
                        }`}
                      />
                    ))}
                  </div>
                  <button 
                    onClick={() => handleFlavorToggle(flavor.name)}
                    className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 hover:text-rose-500 transition-colors"
                  >
                    <span className="google-symbols text-lg">close</span>
                  </button>
                </div>
              </div>
            );
          })}
          {profile.favoriteFlavors.length === 0 && (
            <div className="text-center py-10 opacity-30">
              <span className="google-symbols text-4xl mb-2">science</span>
              <p className="text-[10px] font-black uppercase tracking-[0.2em]">Flavor Genome Uninitialized</p>
            </div>
          )}
        </div>
      </section>

      <div className="space-y-16 px-6">
        {/* Discovery Range */}
        <section className="space-y-8">
           <label className="text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.3em] flex items-center gap-3">
              <span className="google-symbols text-sm text-sunset">travel_explore</span> Discovery Range
           </label>
           <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-100 dark:border-slate-800 space-y-6 shadow-sm">
              <div className="flex justify-between items-center px-2">
                 {DISCOVERY_RANGES.map(range => (
                   <div key={range.id} className="flex flex-col items-center gap-2">
                      <span className={`google-symbols text-xl ${profile.maxDistance === range.id ? 'text-sunset' : 'text-slate-300'}`}>{range.icon}</span>
                      <span className={`text-[8px] font-black uppercase tracking-widest ${profile.maxDistance === range.id ? 'text-sunset' : 'text-slate-400'}`}>{range.label}</span>
                   </div>
                 ))}
              </div>
              <input 
                type="range" min="0" max="3" step="1"
                value={DISCOVERY_RANGES.findIndex(r => r.id === profile.maxDistance)}
                onChange={(e) => {
                  const newRange = DISCOVERY_RANGES[parseInt(e.target.value)].id;
                  setProfile({...profile, maxDistance: newRange});
                  if ('vibrate' in navigator) navigator.vibrate(5);
                }}
                className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sunset"
              />
              <p className="text-center text-[10px] font-bold text-slate-500 italic">
                {DISCOVERY_RANGES.find(r => r.id === profile.maxDistance)?.desc}
              </p>
           </div>
        </section>

        {/* Visual Snap Module */}
        <section className="space-y-6">
           <label className="text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.3em] flex items-center gap-3">
              <span className="google-symbols text-sm text-sunset">photo_camera</span> Visual Craving Log
           </label>
           <div 
             onClick={() => fileInputRef.current?.click()}
             className={`relative h-48 w-full rounded-[3.5rem] border-4 border-dashed transition-all cursor-pointer overflow-hidden flex flex-col items-center justify-center ${
               previewImage ? 'border-sunset bg-black' : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 hover:border-sunset/40'
             }`}
           >
             <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleImageUpload} />
             {previewImage ? (
               <>
                 <img src={previewImage} className="w-full h-full object-cover opacity-60" alt="uploaded dish" />
                 <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                    <span className="google-symbols text-5xl mb-3 animate-pulse">radar</span>
                    <p className="text-[10px] font-black uppercase tracking-widest">Image Identified</p>
                    <button onClick={(e) => { e.stopPropagation(); setPreviewImage(null); }} className="mt-4 bg-white/20 backdrop-blur-xl px-4 py-1.5 rounded-full text-[9px] font-black">CLEAR</button>
                 </div>
               </>
             ) : (
               <div className="text-center space-y-2">
                  <div className="w-16 h-16 bg-white dark:bg-slate-800 rounded-3xl flex items-center justify-center shadow-xl mx-auto">
                    <span className="google-symbols text-3xl text-slate-400">add_a_photo</span>
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Snap or Upload dish photo</p>
               </div>
             )}
           </div>
        </section>

        <div className="pt-4">
          <button 
            onClick={handleSubmit}
            disabled={isLoading}
            className={`w-full py-8 rounded-[3rem] font-black text-lg uppercase tracking-[0.5em] shadow-3xl transition-all duration-700 group relative overflow-hidden ${
              isLoading ? 'bg-slate-100 text-slate-400 cursor-wait' : 'bg-sunset text-white hover:bg-orange-600 active:scale-95'
            }`}
          >
            {isLoading ? (
              <div className="flex items-center justify-center gap-4">
                <span className="google-symbols animate-spin text-3xl">sync</span>
                <span>SCOUTING NODE...</span>
              </div>
            ) : (
              <span className="flex items-center justify-center gap-5">INITIALIZE SCOUT 🚀</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
