
import React from 'react';
import { User } from '../types';

interface ProfileViewProps {
  user: User;
  onLogout?: () => void;
}

const STATS = [
  { label: 'Spots Visited', value: '12', icon: 'location_on', color: 'text-sunset' },
  { label: 'Photos Shared', value: '48', icon: 'photo_camera', color: 'text-mint' },
  { label: 'Health Goal', value: '82%', icon: 'fitness_center', color: 'text-softpink' },
];

export const ProfileView: React.FC<ProfileViewProps> = ({ user, onLogout }) => {
  return (
    <div className="space-y-12 pb-32 animate-in fade-in slide-in-from-bottom-6 duration-700">
      <header className="px-6 pt-12 text-center space-y-6">
        <div className="relative inline-block">
          <div className="w-32 h-32 rounded-[3.5rem] bg-sunset/10 p-1 border-4 border-white dark:border-midnight shadow-2xl overflow-hidden group">
            <img src={user.avatar} alt={user.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
          </div>
          <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-sunset text-white rounded-2xl flex items-center justify-center shadow-xl border-4 border-white dark:border-midnight">
            <span className="google-symbols text-xl">edit</span>
          </div>
        </div>
        
        <div className="space-y-2">
          <h2 className="text-4xl font-serif font-black text-slate-900 dark:text-white leading-none">{user.name}</h2>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">Level 14 Taste Scout</p>
        </div>
      </header>

      <div className="px-6">
        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-8 scout-card-shadow space-y-8">
          <div className="space-y-4">
             <div className="flex justify-between items-center">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Gastro-XP Journey</span>
                <span className="text-xs font-black text-sunset">650 / 1000</span>
             </div>
             <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                <div className="h-full bg-gradient-to-r from-sunset to-lemon rounded-full transition-all duration-1000" style={{ width: '65%' }}></div>
             </div>
          </div>

          <div className="grid grid-cols-3 gap-4 border-t border-slate-50 dark:border-slate-800 pt-8">
            {STATS.map((stat) => (
              <div key={stat.label} className="text-center space-y-1">
                <span className={`google-symbols ${stat.color} text-xl`}>{stat.icon}</span>
                <p className="text-xl font-black text-slate-900 dark:text-white leading-none">{stat.value}</p>
                <p className="text-[7px] font-black uppercase text-slate-400 tracking-tighter">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="px-6 space-y-6">
        <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400 px-2">Achievements Node 🏆</h3>
        <div className="grid grid-cols-2 gap-4">
           {['Wellness Pro', 'Spice King', 'Local Legend', 'Night Owl'].map(badge => (
             <div key={badge} className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border-2 border-slate-50 dark:border-slate-800 flex flex-col items-center gap-3 soft-shadow group hover:border-sunset transition-all">
                <div className="w-14 h-14 bg-sunset/5 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                  {badge === 'Wellness Pro' ? '🥗' : badge === 'Spice King' ? '🌶️' : badge === 'Local Legend' ? '🗺️' : '🌙'}
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-800 dark:text-slate-200">{badge}</span>
             </div>
           ))}
        </div>
      </div>

      <div className="px-10">
        <button 
          onClick={onLogout}
          className="w-full py-6 rounded-[2rem] bg-rose-50 dark:bg-rose-950/20 text-rose-600 text-[10px] font-black uppercase tracking-[0.4em] hover:bg-rose-100 transition-all border border-rose-100 dark:border-rose-900"
        >
          Disconnect Protocol
        </button>
      </div>
    </div>
  );
};
