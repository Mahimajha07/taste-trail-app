
import React, { useState, useRef, useEffect } from 'react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

type LoginStep = 'identifier' | 'otp' | 'profile';

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [step, setStep] = useState<LoginStep>('identifier');
  const [identifier, setIdentifier] = useState('');
  const [authMethod, setAuthMethod] = useState<'email' | 'phone'>('email');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [name, setName] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other' | ''>('');
  const [age, setAge] = useState<number>(25);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  const triggerHaptic = (ms: number | number[]) => {
    if ('vibrate' in navigator) navigator.vibrate(ms);
  };

  const handleIdentifierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier) return;
    setIsSubmitting(true);
    triggerHaptic(20);
    // Simulate sending OTP
    setTimeout(() => {
      setIsSubmitting(false);
      setStep('otp');
    }, 1200);
  };

  const handleOtpChange = (value: string, index: number) => {
    if (isNaN(Number(value))) return;
    const newOtp = [...otp];
    newOtp[index] = value.substring(value.length - 1);
    setOtp(newOtp);

    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
    triggerHaptic(5);
  };

  const handleOtpKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.some(digit => !digit)) return;
    setIsSubmitting(true);
    triggerHaptic([10, 30]);
    // Simulate verification
    setTimeout(() => {
      setIsSubmitting(false);
      setStep('profile');
    }, 1000);
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !gender) return;
    
    setIsSubmitting(true);
    triggerHaptic([10, 30, 10, 50]);

    setTimeout(() => {
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        name: name.trim(),
        gender,
        age,
        email: authMethod === 'email' ? identifier : undefined,
        phone: authMethod === 'phone' ? identifier : undefined,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}&mood[]=happy`
      };
      onLogin(newUser);
    }, 800);
  };

  const isIdentifierValid = identifier.length > 5;
  const isOtpValid = otp.every(digit => digit !== '');
  const isProfileValid = name.trim().length >= 2 && gender !== '';

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-950 relative overflow-hidden transition-colors duration-500">
      {/* Dynamic Ambient Background */}
      <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] bg-rose-500/10 rounded-full blur-[120px] opacity-50 animate-pulse"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[400px] h-[400px] bg-amber-500/10 rounded-full blur-[100px] opacity-30 animate-pulse" style={{ animationDelay: '1s' }}></div>

      <div className="w-full max-w-md z-10">
        <div className="text-center mb-10">
          <div className="relative w-24 h-24 mx-auto mb-6">
             <div className="absolute inset-0 bg-rose-500 rounded-[2.5rem] blur-2xl opacity-20 animate-dna"></div>
             <div className="relative w-full h-full bg-white dark:bg-slate-900 rounded-[2.5rem] flex items-center justify-center shadow-2xl border-4 border-slate-100 dark:border-slate-800">
                <span className="text-5xl">{step === 'identifier' ? '🐒' : step === 'otp' ? '🔑' : '✨'}</span>
             </div>
          </div>
          <h1 className="text-4xl font-serif font-black text-slate-900 dark:text-white leading-none tracking-tighter">TasteTrail</h1>
          <p className="text-[10px] font-black text-rose-600 uppercase tracking-[0.4em] mt-4">
            {step === 'identifier' ? 'Grounded Auth Node' : step === 'otp' ? 'Encrypted Verification' : 'Finalizing Profile'}
          </p>
        </div>

        <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-3xl rounded-[3.5rem] p-10 shadow-scout-card-shadow border-4 border-white dark:border-slate-800 space-y-10">
          
          {/* Progress Pips */}
          <div className="flex justify-center gap-2">
            {(['identifier', 'otp', 'profile'] as const).map((s, idx) => (
              <div key={s} className={`h-1.5 rounded-full transition-all duration-500 ${
                step === s ? 'w-10 bg-rose-600' : (idx < ['identifier', 'otp', 'profile'].indexOf(step) ? 'w-1.5 bg-emerald-500' : 'w-1.5 bg-slate-200 dark:bg-slate-800')
              }`} />
            ))}
          </div>

          {step === 'identifier' && (
            <form onSubmit={handleIdentifierSubmit} className="space-y-8 animate-in slide-in-from-bottom-6 duration-500">
              <div className="space-y-4">
                <div className="flex gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
                  <button 
                    type="button" 
                    onClick={() => { setAuthMethod('email'); setIdentifier(''); }}
                    className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${authMethod === 'email' ? 'bg-white dark:bg-slate-700 text-rose-600 shadow-md' : 'text-slate-400'}`}
                  >
                    Email
                  </button>
                  <button 
                    type="button" 
                    onClick={() => { setAuthMethod('phone'); setIdentifier(''); }}
                    className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${authMethod === 'phone' ? 'bg-white dark:bg-slate-700 text-rose-600 shadow-md' : 'text-slate-400'}`}
                  >
                    Phone
                  </button>
                </div>
                
                <div className="relative group">
                  <span className="google-symbols absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-rose-500 transition-colors">
                    {authMethod === 'email' ? 'alternate_email' : 'smartphone'}
                  </span>
                  <input 
                    type={authMethod === 'email' ? 'email' : 'tel'}
                    required
                    placeholder={authMethod === 'email' ? 'hello@palate.com' : '+91 98765 43210'}
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800/50 border-2 border-slate-100 dark:border-slate-800 focus:border-rose-400 rounded-3xl pl-14 pr-6 py-6 font-bold text-lg text-slate-800 dark:text-white outline-none transition-all shadow-inner"
                  />
                </div>
              </div>

              <button 
                type="submit"
                disabled={!isIdentifierValid || isSubmitting}
                className={`w-full py-8 rounded-[2.5rem] font-black text-lg shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95 ${
                  isIdentifierValid && !isSubmitting
                    ? 'bg-rose-600 text-white hover:bg-rose-700 shadow-rose-200 dark:shadow-rose-900/20' 
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                }`}
              >
                {isSubmitting ? (
                  <span className="google-symbols animate-spin">sync</span>
                ) : (
                  <>Send Gastro-Code <span className="google-symbols">arrow_forward</span></>
                )}
              </button>
            </form>
          )}

          {step === 'otp' && (
            <form onSubmit={handleOtpSubmit} className="space-y-10 animate-in slide-in-from-right-8 duration-500">
              <div className="text-center space-y-2">
                <h3 className="text-xl font-black text-slate-800 dark:text-slate-200">Enter Code</h3>
                <p className="text-[11px] font-medium text-slate-400 leading-relaxed">
                  We've synced a verification code to <br/>
                  <span className="text-slate-900 dark:text-white font-black">{identifier}</span>
                </p>
              </div>

              <div className="flex justify-between gap-2">
                {otp.map((digit, idx) => (
                  <input
                    key={idx}
                    ref={el => otpRefs.current[idx] = el}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(e.target.value, idx)}
                    onKeyDown={(e) => handleOtpKeyDown(e, idx)}
                    className="w-12 h-16 bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-800 focus:border-rose-500 rounded-2xl text-center font-black text-2xl text-slate-900 dark:text-white outline-none transition-all shadow-xl"
                  />
                ))}
              </div>

              <div className="flex flex-col gap-4">
                <button 
                  type="submit"
                  disabled={!isOtpValid || isSubmitting}
                  className={`w-full py-8 rounded-[2.5rem] font-black text-lg shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95 ${
                    isOtpValid && !isSubmitting
                      ? 'bg-rose-600 text-white shadow-rose-200 dark:shadow-rose-900/20' 
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                  }`}
                >
                  {isSubmitting ? <span className="google-symbols animate-spin">sync</span> : 'Verify Code'}
                </button>
                <button 
                  type="button"
                  onClick={() => setStep('identifier')}
                  className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-rose-600 transition-colors"
                >
                  Edit {authMethod === 'email' ? 'Email' : 'Number'}
                </button>
              </div>
            </form>
          )}

          {step === 'profile' && (
            <form onSubmit={handleFinalSubmit} className="space-y-8 animate-in slide-in-from-right-8 duration-500">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Full Identity</label>
                  <input 
                    type="text"
                    required
                    placeholder="E.g. Chef Gully"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-800 focus:border-rose-400 rounded-3xl px-8 py-6 font-bold text-lg text-slate-800 dark:text-white outline-none transition-all shadow-inner"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Gender Node</label>
                  <div className="grid grid-cols-3 gap-3">
                    {(['Male', 'Female', 'Other'] as const).map(g => (
                      <button
                        key={g}
                        type="button"
                        onClick={() => { setGender(g); triggerHaptic(10); }}
                        className={`py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest border-2 transition-all ${
                          gender === g 
                            ? 'bg-slate-900 dark:bg-white border-slate-900 dark:border-white text-white dark:text-slate-900 shadow-xl' 
                            : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-400'
                        }`}
                      >
                        {g === 'Other' ? 'N/B' : g}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Maturity Cycles</label>
                  <div className="flex items-center gap-6 bg-slate-50 dark:bg-slate-800 p-2 rounded-[2.5rem] border-2 border-slate-100 dark:border-slate-700">
                    <button type="button" onClick={() => { setAge(Math.max(1, age - 1)); triggerHaptic(5); }} className="w-14 h-14 bg-white dark:bg-slate-700 rounded-3xl shadow-lg flex items-center justify-center text-rose-600">
                      <span className="google-symbols">remove</span>
                    </button>
                    <div className="flex-1 text-center">
                      <span className="text-4xl font-black text-slate-900 dark:text-white">{age}</span>
                      <span className="text-[9px] font-black text-slate-400 block -mt-1 uppercase">Years</span>
                    </div>
                    <button type="button" onClick={() => { setAge(Math.min(100, age + 1)); triggerHaptic(5); }} className="w-14 h-14 bg-white dark:bg-slate-700 rounded-3xl shadow-lg flex items-center justify-center text-rose-600">
                      <span className="google-symbols">add</span>
                    </button>
                  </div>
                </div>
              </div>

              <button 
                type="submit"
                disabled={!isProfileValid || isSubmitting}
                className={`w-full py-8 rounded-[2.5rem] font-black text-xl shadow-2xl transition-all flex items-center justify-center gap-4 active:scale-95 ${
                  isProfileValid && !isSubmitting
                    ? 'bg-rose-600 text-white shadow-rose-200 dark:shadow-rose-900/20' 
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                }`}
              >
                {isSubmitting ? <span className="google-symbols animate-spin text-4xl">sync</span> : <>Initialize Scout <span className="google-symbols">bolt</span></>}
              </button>
            </form>
          )}

          <p className="text-center text-[9px] text-slate-400 font-bold uppercase tracking-[0.2em]">
            Secured by TasteTrail Grounding Network
          </p>
        </div>
      </div>
    </div>
  );
};
