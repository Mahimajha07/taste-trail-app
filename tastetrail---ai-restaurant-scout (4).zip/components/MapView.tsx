
import React, { useEffect, useRef } from 'react';
import { Restaurant } from '../types';

declare const L: any;

interface MapViewProps {
  restaurants: Restaurant[];
  userLocation: { lat: number; lng: number } | null;
  onSelectRestaurant: (index: number) => void;
  selectedId: number | null;
}

const CUISINE_EMOJI_MAP: Record<string, string> = {
  'Italian': '🍝',
  'Japanese': '🍣',
  'Mexican': '🌮',
  'Thai': '🍲',
  'Indian': '🍛',
  'North Indian': '🍗',
  'South Indian': '🫓',
  'Bengali': '🐟',
  'Maharashtrian': '🥘',
  'French': '🥐',
  'Chinese': '🥢',
  'American': '🍔',
  'Healthy': '🥗',
  'Desserts': '🍰',
  'Fast Food': '🍟',
  'Street Food': '🍕',
  'Bakery': '🥐',
  'Pizza': '🍕',
  'Seafood': '🦐',
};

export const MapView: React.FC<MapViewProps> = ({ restaurants, userLocation, onSelectRestaurant, selectedId }) => {
  const mapRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<any[]>([]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const initialPos: [number, number] = userLocation 
      ? [userLocation.lat, userLocation.lng] 
      : (restaurants.length > 0 && restaurants[0].location 
          ? [restaurants[0].location.lat, restaurants[0].location.lng] 
          : [20.5937, 78.9629]);

    mapRef.current = L.map(containerRef.current, {
      zoomControl: false,
      scrollWheelZoom: true
    }).setView(initialPos, 14);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap'
    }).addTo(mapRef.current);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!mapRef.current) return;

    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    const bounds = L.latLngBounds([]);

    restaurants.forEach((r, idx) => {
      if (!r.location?.lat || !r.location?.lng) return;

      const isSelected = selectedId === idx;
      const emoji = CUISINE_EMOJI_MAP[r.cuisine] || '🍽️';
      
      const icon = L.divIcon({
        className: 'custom-marker-wrapper',
        html: `
          <div class="group relative flex items-center justify-center transition-all duration-500 ${isSelected ? 'scale-125 z-[1000]' : 'z-10'}">
            <div class="absolute inset-0 bg-sunset blur-md opacity-20 rounded-full animate-pulse"></div>
            <div class="relative w-12 h-12 bg-white dark:bg-slate-900 rounded-[1.5rem] flex items-center justify-center shadow-xl border-2 ${isSelected ? 'border-sunset' : 'border-slate-100 dark:border-slate-800'} transition-all hover:scale-110">
              <span class="text-2xl" role="img" aria-label="${r.cuisine}">${emoji}</span>
              <div class="absolute -top-1 -right-1 bg-midnight text-white text-[8px] font-black px-1.5 py-0.5 rounded-full border-2 border-white">
                ${r.matchScore}%
              </div>
            </div>
          </div>
        `,
        iconSize: [48, 48],
        iconAnchor: [24, 24]
      });

      const marker = L.marker([r.location.lat, r.location.lng], { icon })
        .addTo(mapRef.current!)
        .on('click', (e: any) => {
          L.DomEvent.stopPropagation(e);
          onSelectRestaurant(idx);
          marker.openPopup();
        });

      const deliveryUrl = r.swiggyUrl || r.zomatoUrl || r.orderUrl || r.uberEatsUrl;
      const platformName = r.swiggyUrl ? 'Swiggy' : r.zomatoUrl ? 'Zomato' : r.uberEatsUrl ? 'Uber Eats' : 'Direct';

      marker.bindPopup(`
        <div class="p-6 font-sans min-w-[300px] bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl border border-slate-100 dark:border-slate-800">
          <div class="flex justify-between items-start mb-3">
             <p class="text-[10px] font-black text-sunset uppercase tracking-widest flex items-center gap-2">
               <span class="w-2 h-2 bg-sunset rounded-full animate-pulse"></span>
               ${r.cuisine} Node
             </p>
             <span class="text-[9px] font-black text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-100">${r.healthScore || 85}% Wellness</span>
          </div>
          <h4 class="font-black text-slate-950 dark:text-white text-2xl mb-1 leading-none tracking-tighter">${r.name}</h4>
          <p class="text-[12px] text-slate-500 mb-5 font-medium leading-relaxed italic line-clamp-2">"${r.whyMatch}"</p>
          
          <div class="flex items-center justify-between py-4 border-y border-slate-50 dark:border-slate-800 mb-6">
            <div class="flex flex-col">
              <span class="text-base font-black text-amber-500 flex items-center gap-1">
                 <span class="google-symbols text-lg filled">star</span> ${r.rating}
              </span>
              <span class="text-[9px] font-black text-slate-400 uppercase tracking-widest">${r.priceRange}</span>
            </div>
            <div class="text-right">
              <span class="text-sm font-black text-sunset block leading-none">${r.matchScore}% Soul Match</span>
              <span class="text-[8px] font-black text-slate-400 uppercase tracking-tighter">AI Analysis</span>
            </div>
          </div>

          <div class="space-y-3">
             <button 
                onclick="window.dispatchEvent(new CustomEvent('map-book', {detail: '${r.name.replace(/'/g, "\\'")}'}))" 
                class="w-full bg-midnight dark:bg-white text-white dark:text-midnight py-4 rounded-[1.5rem] text-[11px] font-black text-center transition-all active:scale-95 shadow-xl border-b-[6px] border-black/10"
             >
                SECURE TABLE 📅
             </button>
             ${deliveryUrl ? `
                <a href="${deliveryUrl}" target="_blank" rel="noopener" class="w-full bg-sunset py-4 rounded-[1.5rem] text-[10px] font-black text-white text-center no-underline transition-all active:scale-95 shadow-lg flex items-center justify-center gap-2 border-b-[6px] border-black/10">
                  <span class="google-symbols text-xl">moped</span>
                  ORDER NOW ON ${platformName.toUpperCase()}
                </a>
             ` : ''}
          </div>
        </div>
      `, {
        closeButton: false,
        offset: [0, -20],
        className: 'scout-map-popup'
      });

      markersRef.current.push(marker);
      bounds.extend([r.location.lat, r.location.lng]);
    });

    if (userLocation) {
      const userIcon = L.divIcon({
        className: 'user-location-marker',
        html: `
          <div class="relative flex items-center justify-center">
            <div class="absolute inset-0 w-10 h-10 bg-blue-500/20 rounded-full animate-ping"></div>
            <div class="w-6 h-6 bg-blue-600 rounded-full border-2 border-white shadow-2xl ring-4 ring-blue-500/10"></div>
          </div>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 20]
      });
      L.marker([userLocation.lat, userLocation.lng], { icon: userIcon, zIndexOffset: 2000 }).addTo(mapRef.current);
      bounds.extend([userLocation.lat, userLocation.lng]);
    }

    if (restaurants.length > 0) {
      mapRef.current.fitBounds(bounds, { padding: [100, 100], maxZoom: 15 });
    }
  }, [restaurants, userLocation, selectedId]);

  const handleRecenter = () => {
    if (userLocation && mapRef.current) {
      mapRef.current.setView([userLocation.lat, userLocation.lng], 15, { animate: true });
    }
  };

  return (
    <div className="w-full h-[550px] md:h-[750px] relative animate-in zoom-in duration-700">
      <div ref={containerRef} className="absolute inset-0 border-[12px] border-sunset dark:border-slate-800 shadow-3xl overflow-hidden rounded-[4.5rem] z-10" />
      
      {/* Map Controls */}
      <div className="absolute top-12 left-12 z-20 space-y-4">
        <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl px-8 py-4 rounded-[2rem] shadow-2xl border-2 border-sunset/20 dark:border-slate-700 flex items-center gap-4">
          <div className="w-3 h-3 bg-sunset rounded-full animate-pulse shadow-[0_0_15px_#FF6B35]"></div>
          <span className="text-[12px] font-black uppercase tracking-[0.3em] text-slate-800 dark:text-slate-100">Synchronized Node Map</span>
        </div>
        
        <button 
          onClick={handleRecenter}
          aria-label="Recenter map"
          className="w-16 h-16 bg-white dark:bg-slate-900 rounded-[1.5rem] shadow-2xl flex items-center justify-center text-slate-700 dark:text-slate-200 active:scale-90 transition-all border-2 border-white dark:border-slate-800"
        >
          <span className="google-symbols text-3xl">my_location</span>
        </button>
      </div>

      <style>{`
        .scout-map-popup .leaflet-popup-content-wrapper {
          padding: 0;
          border-radius: 3rem;
          overflow: hidden;
          box-shadow: 0 40px 100px -20px rgba(0, 0, 0, 0.4);
          background: transparent;
        }
        .scout-map-popup .leaflet-popup-content {
          margin: 0;
        }
        .scout-map-popup .leaflet-popup-tip {
          background: white;
          box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .dark .scout-map-popup .leaflet-popup-tip {
          background: #0f172a;
        }
      `}</style>
    </div>
  );
};
