
import React, { useState, useRef, useEffect } from 'react';
import { TasteProfile, FlavorIntensity } from '../types';

interface TasteFormProps {
  onSearch: (profile: TasteProfile, photoBase64?: string) => void;
  isLoading: boolean;
}

const RECENT_SEARCHES_KEY = 'tastetrail_recent_v2';

const DISCOVERY_RANGES = [
  { id: '5km', label: 'Nearby', desc: 'Walking distance', icon: 'directions_walk' },
  { id: '25km', label: 'Citywide', desc: 'Commutable range', icon: 'directions_car' },
  { id: '100km', label: 'Regional', desc: 'Wider expedition', icon: 'explore' },
  { id: 'Global', label: 'Global', desc: 'World-class gems', icon: 'public' }
];

const QUICK_FILTERS = [
  { id: 'trending', label: 'Trending', icon: 'local_fire_department' },
  { id: 'healthy', label: 'Healthy', icon: 'eco' },
  { id: 'budget', label: 'Budget-friendly', icon: 'payments' },
  { id: 'fast', label: 'Fast Delivery', icon: 'bolt' },
];

const SUGGESTION_POOL = [
  "Spicy Ramen", "Sushi Platter", "Butter Chicken", "Keto Salad", "Avocado Toast",
  "Truffle Pasta", "Margarita Pizza", "Dim Sums", "Paneer Tikka", "Hyderabadi Biryani",
  "Vegan Burger", "Matcha Latte", "Street Tacos", "Healthy Smoothie Bowl", "Cheesecake"
];

const FLAVOR_OPTIONS = [
  { name: 'Spicy', emoji: '🌶️', color: 'bg-rose-500' },
  { name: 'Sweet', emoji: '🍬', color: 'bg-amber-400' },
  { name: 'Umami', emoji: '🍄', color: 'bg-slate-700' },
  { name: 'Tangy', emoji: '🍋', color: 'bg-yellow-400' },
  { name: 'Salty', emoji: '🧂', color: 'bg-blue-400' },
  { name: 'Bitter', emoji: '☕', color: 'bg-stone-600' },
  { name: 'Smoky', emoji: '🪵', color: 'bg-orange-800' },
  { name: 'Creamy', emoji: '🥛', color: 'bg-blue-200' },
];

const TEXTURE_OPTIONS = [
  { id: 'crispy', label: 'Crispy', emoji: '🥨' },
  { id: 'creamy', label: 'Creamy', emoji: '🍦' },
  { id: 'chewy', label: 'Chewy', emoji: '🍡' },
  { id: 'tender', label: 'Tender', emoji: '🥩' },
  { id: 'crunchy', label: 'Crunchy', emoji: '🥕' },
  { id: 'silky', label: 'Silky', emoji: '🍮' },
];

export const TasteForm: React.FC<TasteFormProps> = ({ onSearch, isLoading }) => {
  const [profile, setProfile] = useState<TasteProfile>({
    dietaryPreferences: [], favoriteFlavors: [], preferredTextures: [], preferredCuisines: [], features: [],
    atmosphere: "Lively", diningTheme: "Casual", budget: "₹₹", customNotes: "",
    occasion: 'Solo', maxDistance: "25km", ageGroup: 'Adult', comfortPreference: 'Casual',
    healthGoal: 'Balanced', spiceTolerance: 'Medium', isHealthyScout: false, onlineOrderingOnly: false,
    deliveryPriority: 'Quality'
  });

  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [searchInput, setSearchInput] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isFlavorDropdownOpen, setIsFlavorDropdownOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const stored = localStorage.getItem(RECENT_SEARCHES_KEY);
    if (stored) setRecentSearches(JSON.parse(stored));
  }, []);

  const saveToHistory = (query: string) => {
    if (!query.trim()) return;
    const updated = [query, ...recentSearches.filter(s => s !== query)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
  };

  const handleInputChange = (val: string) => {
    setSearchInput(val);
    if (val.trim().length > 1) {
      const filtered = SUGGESTION_POOL.filter(s => s.toLowerCase().includes(val.toLowerCase())).slice(0, 5);
      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const selectSuggestion = (s: string) => {
    setSearchInput(s);
    setShowSuggestions(false);
    onSearch({ ...profile, customNotes: s }, previewImage || undefined);
    saveToHistory(s);
  };

  const toggleSelection = (list: string[], item: string, key: keyof TasteProfile) => {
    const newList = list.includes(item) ? list.filter(i => i !== item) : [...list, item];
    setProfile({...profile, [key]: newList});
    if ('vibrate' in navigator) navigator.vibrate(10);
  };

  const handle