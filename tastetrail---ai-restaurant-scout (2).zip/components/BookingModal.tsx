
import React, { useState } from 'react';
import { Restaurant, Booking } from '../types';

interface BookingModalProps {
  restaurant: Restaurant;
  onClose: () => void;
  onConfirm: (booking: Booking) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ restaurant, onClose, onConfirm }) => {
  const [bookingState, setBookingState] = useState<'config' | 'success'>('config');
  const [bookingGuests, setBookingGuests] = useState(2);
  const [bookingTime, setBookingTime] = useState('19:30');
  const [bookingDate, setBookingDate] = useState(new Date().toISOString().split('T')[0]);

  const handleFinalizeBooking = () => {
    const newBooking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      restaurantName: restaurant.name,
      date: bookingDate,
      time: bookingTime,
      guests: bookingGuests,
      status: 'confirmed',
      cuisine: restaurant.cuisine,
      address: restaurant.address
    };
    
    onConfirm(newBooking);
    setBookingState('success');
    if ('vibrate' in navigator) navigator.vibrate([20, 40, 60]);
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-slate-950/98 backdrop-blur-3xl flex flex-col items-center justify-center text-white p-6 text-center animate-in fade-in zoom-in duration-300">
      <div className="w-full max-w-sm space-y-8 no-scrollbar overflow-y-auto max-h-full py-4">
        {bookingState === 'config' ? (
          <>
            <div className="space-y-2">
              <span className="google-symbols text-6xl text-rose-500">calendar_month</span>
              <h3 className="text-4xl font-serif font-black">{restaurant.name}</h3>
              <p className="text-[10px] font-black uppercase tracking-[0.3em] opacity-40">Syncing reservation node</p>
            </div>
            
            <div className="space-y-4">
              <div className="bg-white/5 p-5 rounded-[2rem] border border-white/10 space-y-3">
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 block text-left ml-2">Reservation Date</span>
                <input 
                  type="date" 
                  value={bookingDate} 
                  onChange={(e) => setBookingDate(e.target.value)}
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-sm font-black text-white outline-none focus:border-rose-500 transition-all"
                />
              </div>

              <div className="bg-white/5 p-5 rounded-[2rem] border border-white/10 space-y-3">
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 block text-left ml-2">Guest Count</span>
                <div className="flex justify-between items-center px-4">
                  <button onClick={() => setBookingGuests(Math.max(1, bookingGuests-1))} className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center hover:bg-white/20"><span className="google-symbols">remove</span></button>
                  <span className="text-4xl font-black">{bookingGuests}</span>
                  <button onClick={() => setBookingGuests(bookingGuests+1)} className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center hover:bg-white/20"><span className="google-symbols">add</span></button>
                </div>
              </div>
              
              <div className="bg-white/5 p-5 rounded-[2rem] border border-white/10 space-y-3 text-center">
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 block text-left ml-2">Preferred Time</span>
                <div className="grid grid-cols-3 gap-2">
                  {['18:30', '19:30', '20:30', '21:00', '21:30', '22:00'].map(t => (
                    <button key={t} onClick={() => setBookingTime(t)} className={`py-3 rounded-xl text-[10px] font-black transition-all ${bookingTime === t ? 'bg-rose-600 text-white' : 'bg-white/5 text-slate-400'}`}>{t}</button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <button onClick={onClose} className="flex-1 py-6 bg-white/5 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-white/10 transition-all">Abort</button>
              <button onClick={handleFinalizeBooking} className="flex-[2] py-6 bg-rose-600 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-2xl shadow-rose-500/20 hover:bg-rose-700 transition-all">Finalize Sync</button>
            </div>
          </>
        ) : (
          <div className="space-y-8 animate-in zoom-in duration-500">
            <div className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(16,185,129,0.5)]">
              <span className="google-symbols text-5xl">verified</span>
            </div>
            <div className="space-y-2">
              <h3 className="text-4xl font-serif font-black">Gastro-Sync Ready</h3>
              <p className="text-xs font-black uppercase tracking-widest text-emerald-400">Table secured for {bookingGuests} at {bookingTime} on {bookingDate}</p>
            </div>
            <button onClick={onClose} className="px-10 py-4 bg-white/10 rounded-full text-xs font-black uppercase hover:bg-white/20 transition-all">Dismiss</button>
          </div>
        )}
      </div>
    </div>
  );
};
