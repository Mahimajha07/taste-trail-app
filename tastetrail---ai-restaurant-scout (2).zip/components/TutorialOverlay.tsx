
import React, { useState } from 'react';

interface TutorialOverlayProps {
  onComplete: () => void;
}

export const TutorialOverlay: React.FC<TutorialOverlayProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);

  const steps = [
    {
      title: "Tap to Scout",
      text: "Tap Chef Gully to describe your craving. He finds regional spices and deep deals instantly!",
      icon: "🐒",
      gesture: "touch_app",
      pos: "bottom-40 right-10"
    },
    {
      title: "Detail Nodes",
      text: "Tap any restaurant to open its Detail Node. Reviews, ordering links, and health metrics are all inside!",
      icon: "🍽️",
      gesture: "gesture",
      pos: "center"
    },
    {
      title: "Wellness Radar",
      text: "Toggle the Wellness Radar to match your protein and calorie goals. It audits every menu for you.",
      icon: "🥗",
      gesture: "swipe_up",
      pos: "bottom-40 left-10"
    }
  ];

  const current = steps[step];

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
      if ('vibrate' in navigator) navigator.vibrate(10);
    } else {
      onComplete();
    }
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-midnight/90 backdrop-blur-3xl flex flex-col items-center justify-center p-8 text-center" onClick={handleNext}>
      
      {/* Hand Gesture Instruction Visual */}
      {current.pos !== 'center' && (
        <div className={`fixed z-[2010] animate-bounce-horizontal pointer-events-none ${current.pos}`}>
          <div className="relative">
             <span className="google-symbols text-7xl text-sunset drop-shadow-[0_0_20px_#FF6B35]">pan_tool_alt</span>
             <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-white px-3 py-1 rounded-full text-[10px] font-black text-sunset uppercase tracking-widest shadow-lg">
                Tap Here
             </div>
          </div>
        </div>
      )}

      <div className="max-w-xs space-y-12 animate-in zoom-in duration-500 relative z-[2020]">
        <div className="relative mx-auto w-40 h-40 bg-white rounded-[3.5rem] flex items-center justify-center text-8xl shadow-2xl border-8 border-sunset">
           {current.icon}
           <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-mint rounded-full flex items-center justify-center text-white shadow-xl border-4 border-white animate-pulse">
              <span className="google-symbols text-3xl">{current.gesture}</span>
           </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-4xl font-serif font-black text-white leading-tight">{current.title}</h2>
          <p className="text-slate-300 font-medium text-xl leading-relaxed">{current.text}</p>
        </div>

        <div className="pt-12 space-y-8">
          <div className="flex justify-center gap-3">
            {steps.map((_, i) => (
              <div key={i} className={`h-2.5 rounded-full transition-all duration-500 ${i === step ? 'w-12 bg-sunset' : 'w-2.5 bg-white/10'}`} />
            ))}
          </div>
          <button className="w-full bg-sunset text-white py-6 rounded-[2.5rem] font-black uppercase tracking-[0.5em] text-sm shadow-2xl active:scale-95 transition-all">
            {step === steps.length - 1 ? "Let's Eat!" : "Next Guide"}
          </button>
        </div>
      </div>
      
      <style>{`
        @keyframes bounce-h {
          0%, 100% { transform: translateY(0) scale(1); }
          50% { transform: translateY(-30px) scale(1.1); }
        }
        .animate-bounce-horizontal { animation: bounce-h 2s ease-in-out infinite; }
      `}</style>
    </div>
  );
};
